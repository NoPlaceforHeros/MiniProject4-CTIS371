/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.miniproject4idk;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author School Tiempo
 */
public class Main {

     private final static int N = 100000; //was once 20
    private static Random rand = new Random();
    private static DecimalFormat formater = new DecimalFormat("0.00");
    private static long now;
    private static double elasped;
    public static void main(String[] args) {
      int[] a = new int[N];
        for (int i = 0; i < N; i++) {
            a[i] = rand.nextInt(1000000); // was 100000
        }
       System.out.println("Unsorted " + Arrays.toString(a));
       int searchValue = 19;
       now = System.nanoTime();
        int sequentialResult = sequentialSearch(a, searchValue, 0, a.length);
        elasped = (System.nanoTime() - now) / 1.e6;
        System.out.println("Sequential search result: " + sequentialResult);
        System.out.println("Sequential search: " + formater.format(elasped));
        
        
        now = System.nanoTime();
        quickSort(a, 0, N);
        elasped = (System.nanoTime() - now)/1.e6;//converted to ms
        System.out.println("Quick sort " + formater.format(elasped));
        
        
         //////2/25/22
         System.out.println("Sorted " + Arrays.toString(a));       
        now = System.nanoTime();
        int binaryResult = binarySearch(a, searchValue, 0, a.length);
        elasped = (System.nanoTime() - now) / 1.e6;
        System.out.println("Binary search result: " + binaryResult);
        System.out.println("Binary search: " + formater.format(elasped));
         //////2/25/22
        
       // System.out.println("Sorted: " + Arrays.toString(a));
        
        shuffleArray(a);

       
       
       //System.out.println("Sorted: " + Arrays.toString(a));
       
       
        now = System.nanoTime();
        selectionSort(a, 0, N);
        elasped = (System.nanoTime() - now)/1.e6;//converted to ms
        System.out.println("Selective sort " + formater.format(elasped));
        
        // System.out.println("Sorted: " + Arrays.toString(a));
        
        shuffleArray(a);
         now = System.nanoTime();
        insertionSort(a, 0, N);
        elasped = (System.nanoTime() - now)/1.e6;//converted to ms
        System.out.println("Selective sort " + formater.format(elasped));
        
    }
    public static int binarySearch(int[] a, int searchValue, int first,
           int last){
    int result = -1; //what we return if the searchValur isint in the array
    //find the midpoint of the index
    int mid = first + (last - 1 - first) / 2;
    if (first > last) {
        result = -1; //the elememnt isnt in the subarray
       
    }
    else if (a[mid] == searchValue) {
        result = mid;    //we got lucky and the search value was at the mid point
        
    }
     else if (a[mid] > searchValue) {
        //search the first half
        result = binarySearch(a, searchValue, first ,mid -1);   
        
    }
     else {
         //otherwise search the second half
         result = binarySearch(a, searchValue, mid + 1, last);
     }
       return result; 
}
    
    
    
    public static int sequentialSearch(int[] a, int searchValue, int first,
            int last){
        //start at the begining
        int index = first;
        //if you dont find the value we're looking for, we'll return -1
        int result = -1;
        //now step through the array
        while (index < last) {
            if (a[index] == searchValue){
                //weve found it so update the resultand break free from the loop
                result = index;
                break;
            }
            //otherwise, go on to the next index
            index++;
        }
        //return the result: the index if we found it; -1 of we didnt
        return result;
    }
    
     //////2/25/22
    public static void quickSort(int[] a, int first, int last){
        //only do quicksort for more than threee array elements
        if(last - first > 3){
//whats the middle element
int mid = first + (last - first) / 2;
//sort the first, middle and last elemements
            if (a[first] > a[mid]){
                swapElements(a, first, mid);
            }
            if (a[first] > a[last - 1]){
                swapElements(a, first, last - 1);
            }
            //have the pivot to the end
             swapElements(a,mid,last - 1);
             int pivotValue = a[last -1];
             
             //start from both sides and work inwards
             int indexFromLeft = first + 1;
             int indexFromRight = last - 2;
             boolean done = false; //this becomes true once all the elements
             //are positional relative to the pivot
             while (!done){
                 //Move from the left until we find an ele,ment greaterthan the pivot
                 while (a[indexFromLeft] < pivotValue){
                     indexFromLeft++;
                 }
                 //now move from the rihht until we finde an element less than the pivot
                 while (a[indexFromRight] > pivotValue){
                     indexFromRight--;
                 }
                 //proviced that the lefr and right pointers have not crossed
                 //sweap those elements
                 if (indexFromLeft < indexFromRight){
                     swapElements(a, indexFromLeft, indexFromRight);
                     indexFromLeft++;
                     indexFromRight--;
                 } else {
                     done = true;
                 }
             }
             //once the pointers cross move the pivot to the corrrect locatuon
             swapElements(a, last - 1, indexFromLeft);
             //Lets use the quicksort to sort each subarray on either side of the pivot
             quickSort(a, first, indexFromLeft - 1);
             quickSort(a, indexFromLeft, last);      
        }
        else {
            selectionSort(a, first, last);
        }
    }
    
    
    //selcetion sort
    //find the smallest element in the unsorted part of the array
    //swap it with the first element in the unsorted part of the array
    public static void selectionSort(int[] a, int first, int last){
        //sort a between indices first and last, inclusive
        //start at the first index
        for (int i = first; i < last; i++){
            //find the smallest value in the array
            //initialize with the first element in the unsorted part of the array
            int small = a[i];
            int iSmall = i;
            //now look for the smallest element
            for (int j = i + 1; j < last; j++){
                if (a[j] < small) {
                    small = a[j];
                    iSmall = j;
                }
            
           }
            //we now know the smallest valur in the unsorted array
            if (i != iSmall){ //if
                swapElements(a, i, iSmall);
            }
        }
    }
    public static void insertionSort(int[] a, int first, int last){
        //start at index first +1
        for (int i = first + 1; i < last; i++){
            //store the values that we'll insert
            int next = a[i];
            //start searching backwards for where we're going to insert next
            int iFill = i - 1;
            while (iFill >= 0 && next < a[iFill]){
                //as long as this is true, move the iFill element up one to make space
                a[iFill + 1] = a[iFill];
                iFill--;
            }
        }
    }
    //Swap two elements
    public static void swapElements(int[] a, int i, int j){
        int temp = a[i];
        a[i] = a[j];
         a[j] = temp;       
    }
    //shuffle the array
    public static void shuffleArray(int[] a){
    int index;
    
    for (int i = a.length - 1; i > 0; i--) {
        index = rand.nextInt(i + 1);
        swapElements(a, i, index);
    }
    }
    
}
